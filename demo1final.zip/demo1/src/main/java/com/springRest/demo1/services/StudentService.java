package com.springRest.demo1.services;

import com.springRest.demo1.entities.Student;

import java.util.List;

public interface StudentService {

    public List<Student> getStudents();
}
