package com.springRest.demo1.services;

import com.springRest.demo1.entities.Electronics;

import java.util.List;

public interface ElectronicsService {

    public List<Electronics> getElectronics();
}
